var http = require("http")// core module
var path = require("path")
var fs = require("fs")
var queryString=require("querystring")
var url=require("url")
const PORT = 3000

// server 
// req --- stream read events -- data; end
// res -- stream write; write(),end()
var empArray = [{
    "empId": 101,
    "empName": "asha",
    "salary": 1001,
    "deptId": "D1"
}, {
    "empId": 102,
    "empName": "Gaurav",
    "salary": 2000,
    "deptId": "D1"
}, {
    "empId": 103,
    "empName": "Karan",
    "salary": 2000,
    "deptId": "D2"
},
{
    "empId": 104,
    "empName": "Kishan",
    "salary": 3000,
    "deptId": "D1"
},
{
    "empId": 105,
    "empName": "Keshav",
    "salary": 3500,
    "deptId": "D2"
},
{
    "empId": 106,
    "empName": "Pran",
    "salary": 4000
},
{
    "empId": 107,
    "empName": "Saurav",
    "salary": 3800
}
]
var app = http.createServer((req, res) => {
    console.log("Request url: ",req.url)
    reqUrl=url.parse(req.url)
    console.log("Parsed url",reqUrl)
    if(reqUrl.pathname=="/checkLogin")
    {
        console.log(reqUrl.query)
        var querystringObj=queryString.parse(reqUrl.query)
        res.write("Thank u for the submission"+querystringObj.txtUserName)
        res.end()
    }
    else
    if (req.url == "/home") {
        if (req.method == "GET") {
            var bookObj = { bookId: 101, bookName: "Intro to mongodb" }
            res.write(JSON.stringify(bookObj))
            res.end()
        }
    }
    else
        if (req.url == "/employees") {
            if (req.method == "GET") {
                // array of emp
                res.write(JSON.stringify(empArray))
                res.end()

            }
            else
            if(req.method=="POST")
            {
                // insert a record
                // Data is coming as part of body section in the request object
                //client -- write into the request 
                // server -- read from the request  -- readable stream 
                //events -- "data" "end"
                myData="";
                req.on("data",(chunks)=>{
                    myData+=chunks.toString()

                })
                req.on("end",()=>{
                    console.log(myData)
                    empArray.push(JSON.parse(myData))
                    res.write(myData)
                    res.end()
                })


            }
        }
        else
            if (req.url == "/login") {
                if (req.method == "GET") {
                    var fileUrl = path.join(__dirname, "login.html")
                    /* fs.readFile(fileUrl,(err,data)=>{
                        res.write(data.toString())
                        res.end()
                    }) */
                    readStream = fs.createReadStream(fileUrl)
                    readStream.pipe(res)
                    /*  readStream.on("data",(chunks)=>{res.write(chunks.toString())})
                     readStream.on("end",()=>{res.end()})
                     */



                }
            }
            else
    if (req.url == "/image") {
        if (req.method == "GET") {
            // send an image as a response
            var fileUrl = path.join(__dirname, "flower.jpg")
            /* readStream=fs.createReadStream(fileUrl)
            readStream.pipe(res) */
            fs.readFile(fileUrl, (err, data) => {
                res.write(data)
                res.end()
            })
        }
    }
    else
        if (req.url == "/products") {
            if (req.method == "GET") {
                // send a html page
                var str1 = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Products Page</h1>
</body>
</html>
            
            `
                res.write(str1)
                res.end()
            }
        }
        else {
            res.write("Thank u for the request ")
            res.end();// response is over
        }
})
app.listen(PORT, (err) => {
    if (!err)
        console.log(`Server is running at localhost with PORT : ${PORT}`)
})


//C:\Users\anjum\OneDrive\Desktop\walmart-node\Day2  -- windows 
// C:/Users/anjum/OneDrive/Desktop/walmart-node/Day2 -- MACOS
//current folder + "/login.html"
// __dirname + login.html
// path.join(__dirname,"login.html")

//REST
// GET  -- asking for some info; select * from emp
//POST-- sending for some info to be stored; insert into emp values()
// PUT --- update some existing info update emp set value=
// Delete- delete some existing info delete from emp