// use cases -- log information; have a log of the requests 
var fs=require("fs")

var writeStream=fs.createWriteStream("text7.txt")

// write into the writeStream 
// trigger "data --- write()
//"end"  --- end()

writeStream.write("hello Walmart")
writeStream.write("hapi.js was introduced by walmart labs")
writeStream.end()
writeStream.write("This is going to throw an error")

writeStream.on("error",(err)=>{
    console.log("Error writing into the file")

})
