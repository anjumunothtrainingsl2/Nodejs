const fs=require("fs")
var myBuffer=Buffer.alloc(1024)
// read partial contents of file
myBuffer.write("This will be written into the file")
fs.open("text5.txt","w",(err,fd)=>{
    if(err)
    {
        console.log("Error opening the file")
    }
    else
    {
        fs.write(fd,myBuffer,0,myBuffer.length,100,(err)=>{
            if(err)
            {
                console.log("Error reading the file")
            }
            else
            {
                console.log("Contents of the file written:",myBuffer.toString())
            }
            fs.close(fd,(err)=>{
                if(err)
                    console.log("Error closing the file",err)

            })
        })
    }

})


