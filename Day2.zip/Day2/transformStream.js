var zlib=require("zlib")
var fs=require("fs")
const gZib=zlib.createGzip()
var readStream=fs.createReadStream("text7.txt")
var writeStream=fs.createWriteStream("text7.txt.zip")
/* readStream.on("data",(chunk)=>{
    writeStream.write(chunk.toString())
})
readStream.on("end",()=>{
    writeStream.end()
}) */

readStream.pipe(gZib).pipe(writeStream)