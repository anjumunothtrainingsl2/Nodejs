// streams
// readable
// writeable
// duplex
// transform 

// events


// readable stream
// read from a file
// trigger an event "data"--- when it has read the chunk
// trigger an event "end" --- when all the chunks have bben read
var fs=require("fs")
var myData=""
var chunkCtr=0
var readStream=fs.createReadStream("text6.txt",{highWaterMark:100*1024})
readStream.on("data",(chunk)=>{
    myData+=chunk.toString()
    chunkCtr++
})

readStream.on("end",()=>{
    console.log("Chunkctr",chunkCtr)
    //console.log(myData);
})
readStream.on("error",(err)=>{
    console.log("Error ",err)

})

