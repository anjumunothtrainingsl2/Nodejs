// NOde js is event driven
// events --- name of the event, trigger, handler
// custom events; 
var events=require("events") 

var myEventEmitter= new events.EventEmitter()
var messageArr;
function startEventHandler()
{
    console.log("Start event started")
    messageArr=[]
}
myEventEmitter.on("start",startEventHandler)
myEventEmitter.on("pushMessage",(p1)=>{
    messageArr.push(p1)
})

myEventEmitter.on("delayEvent",(p1)=>{
    clearIntervalId=setInterval(()=>{
        messageArr.push(p1)
        console.log(messageArr);//["Training on nodejs","Training on react"]

    },5000)
})

myEventEmitter.on("check",(p1,p2)=>{
    if(p1>p2)
        console.log(`${p1} is greater than ${p2}`)
    else
        console.log(`${p2} is greater than ${p1}`)
    

})
console.log("Command line args:",process.argv)
 var i=parseInt(process.argv[2])
 var j=parseInt(process.argv[3])
myEventEmitter.emit("check",i,j)
myEventEmitter.emit("start")

myEventEmitter.emit("pushMessage","Training on nodejs")

myEventEmitter.emit("pushMessage","Training on react")

myEventEmitter.emit("delayEvent","Training on mongodb")
myEventEmitter.emit("pushMessage","Training on Angular")

console.log(messageArr);//["Training on nodejs","Training on react"]

// once
myEventEmitter.once("clear",()=>{
    clearInterval(clearIntervalId)
    console.log("Inside the clear event")
})
myEventEmitter.emit("clear")

myEventEmitter.emit("clear")

// addListener()
function stopeventListener1()
{
    console.log("stop event triggered --1") 
}
function stopeventListener2()
{
    console.log("stop event triggered --2") 
}
myEventEmitter.addListener("stop",stopeventListener1)
myEventEmitter.addListener("stop",stopeventListener2)

myEventEmitter.emit("stop")
var flag=parseInt(process.argv[4])
console.log(typeof flag)
console.log(flag)
if (flag==1)
{
    myEventEmitter.removeListener("stop",stopeventListener1)
}
myEventEmitter.emit("stop")

myEventEmitter.removeListener("start",startEventHandler)
myEventEmitter.emit("start")





