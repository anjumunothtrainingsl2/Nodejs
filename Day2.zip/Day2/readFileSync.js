const fs=require("fs")
try
{
    result=fs.readFileSync("text6.txt");// sync job. single main thread perform this op
    console.log("Contents of the file:",result.toString())
}
catch(e)
{
    console.log("Error",e)
}

