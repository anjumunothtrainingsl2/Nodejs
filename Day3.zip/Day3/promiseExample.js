function myFunc1(flag)
{
    if(flag==true)
        return Promise.resolve(100)
    else
        return Promise.reject("The passed param is false")
}
var myFlag=false;
myFunc1(myFlag)
.then((p1)=>{
    console.log(p1)
})
.catch((err)=>{
    console.log(err)
})

