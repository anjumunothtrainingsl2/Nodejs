var fs = require("fs")

function DoReadFile(fileUrl) {
    return new Promise((resolve,reject)=>{
        fs.readFile(fileUrl, (err, data) => {
            if (err) {
                reject(err)
            }
            else {
                resolve(data.toString())
            }
        })
    })
    
}

function myFunc1()
{
    DoReadFile("../text1.txt")
    .then((data)=>{console.log(data)})
    .catch((err)=>{console.log(err)})
    console.log("hello")
}
myFunc1();//hello,data of the file

async function myFunc2()
{
    try
    {
    res1=await DoReadFile("../text1.txt")
    console.log(res1);
    console.log("$$$$$$$$$$$$$$$")
    res2=await DoReadFile("../text2.txt")
    console.log(res2);
    console.log("$$$$$$$$$$$$$$$")
    res3=await DoReadFile("../text5.txt")
    console.log(res3);
    console.log("$$$$$$$$$$$$$$$")
    res4=await DoReadFile("../text4.txt")
    console.log(res4);
    console.log("$$$$$$$$$$$$$$$")
    console.log("thank you for reading the file")
    }
    catch(err)
    {
        console.log(err)
    }
}
console.log("********************")
myFunc2()
//data from the file; thank you