var http = require("http")
const PORT = 3000;
var empArr = [{
    "empId": 101,
    "empName": "asha",
    "salary": 1001,
    "deptId": "D1"
}, {
    "empId": 102,
    "empName": "Gaurav",
    "salary": 2000,
    "deptId": "D1"
}, {
    "empId": 103,
    "empName": "Karan",
    "salary": 2000,
    "deptId": "D2"
},
{
    "empId": 104,
    "empName": "Kishan",
    "salary": 3000,
    "deptId": "D1"
},
{
    "empId": 105,
    "empName": "Keshav",
    "salary": 3500,
    "deptId": "D2"
},
{
    "empId": 106,
    "empName": "Pran",
    "salary": 4000
},
{
    "empId": 107,
    "empName": "Saurav",
    "salary": 3800
}
]
var app = http.createServer((request, response) => {
    if (request.url == "/employee") {
        if (request.method == "GET") {
            // asking for some info; select *
            response.write(JSON.stringify(empArr))
            response.end()
        }
        else
            if (request.method == "POST") {
                var myData = ""
                request.on("data", (chunks) => {
                    myData += chunks.toString()
                })
                request.on("end", () => {
                    console.log("data from the client as part of the post request", myData)
                    empArr.push(JSON.parse(myData))
                    response.write(myData)
                    response.end()
                })
            }
        else
            if(request.method=="PUT")
            {
                // update some existing info
                // data which is coming as part of body
                var myData = ""
                request.on("data", (chunks) => {
                    myData += chunks.toString()
                })
                request.on("end", () => {
                    console.log("data from the client as part of the put request", myData)
                    var obj=JSON.parse(myData)
                    var pos=empArr.findIndex((item)=>item.empId == obj.empId)
                    if(pos >=0)
                    {
                        // empId to be updated exists
                        empArr[pos]=obj
                        response.write("Emp Details updated successfully")
                        response.end()
                    }
                    else
                    {
                        response.statusCode=404
                        response.write("Emp Id does not exist")
                        response.end()
                    }
                })
            }
        else
        if(request.method=="DELETE")
        {
            var myData = ""
                request.on("data", (chunks) => {
                    myData += chunks.toString()
                })
                request.on("end", () => {
                    var obj=JSON.parse(myData)
                    var pos=empArr.findIndex(item=> item.empId== obj.empId)
                    if(pos>=0)
                    {
                        // data exists for deletion
                        empArr.splice(pos,1)
                        response.write("Employee details deleted successfully")
                        response.end()

                    }
                    else
                    {
                        response.statusCode=404
                        response.write("Emp Id does not exist for deletion")
                        response.end()
                    }
                })
        }


    }
})

app.listen(PORT, (err) => {
    if (!err) {
        console.log(`Server is running at PORT : ${PORT}`)
    }

})