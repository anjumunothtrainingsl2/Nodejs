var fs = require("fs")
var axios=require("axios")

function DoReadFile(fileUrl) {
    return new Promise((resolve,reject)=>{
        fs.readFile(fileUrl, (err, data) => {
            if (err) {
                reject(err)
            }
            else {
                resolve(data.toString())
            }
        })
    })
    
}

var myFile1="../text1.txt"
var myFile2="../text2.txt"
// event loop

DoReadFile(myFile1)
.then((p1)=>{
    console.log(p1)
    return p1.toUpperCase()// return Promise.resolve(p1.toUpperCase())
})
.then((p2)=>{
    console.log(p2)

})
.catch((err)=>{console.log(err)})


function myFunc2(p1,p2)
{
    var sum1=p1+p2
    var tempObj;
    axios.get("http://localhost:3000/employee")
    .then((res)=>{
        console.log(res.data)
        var tempObj=res.data[0]
        tempObj.location="India"
        console.log(tempObj)
        return axios.post("http://localhost:3000/employee",tempObj)
    })
    .then((res)=>{
        console.log(res.data);

    })
    .catch((err)=>{
        console.log(err)
    })
    sum1+=100;
    console.log(sum1);
    

}
myFunc2(10,20);
//130
// contents of the file
