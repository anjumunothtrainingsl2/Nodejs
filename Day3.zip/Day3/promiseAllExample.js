var fs=require("fs")
function DoReadFile(fileUrl) {
    return new Promise((resolve,reject)=>{
        fs.readFile(fileUrl, (err, data) => {
            if (err) {
                reject(err)
            }
            else {
                console.log(`Reading ${fileUrl}`)
                resolve(data.toString())
            }
        })
    })
    
}
/* var myData=""
DoReadFile("../text1.txt")
.then((p1)=>{
    myData+=p1
    return DoReadFile("../text2.txt")
})
.then((p1)=>{
    myData+=p1
    return DoReadFile("../text3.txt")
})
.then((p1)=>{
    myData+=p1
    return DoReadFile("../text4.txt")
})
.catch((err)=>{
    console.log(err)
})
 */
/* var promise1=DoReadFile("../text1.txt")
var promise2=DoReadFile("../text2.txt")
var promise3=DoReadFile("../text5.txt")
var promise4=DoReadFile("../text4.txt")
// input -- list of promises
// return -- array of the result of the input promises
// promise resolved --- all the input promises resolve
// promise rejected --- any of the input promises gets rejected
Promise.all([promise1,promise2,promise3,promise4])
.then((resArray)=>{
    for(var i=0;i<resArray.length;i++)
    {
    console.log(resArray[i])
    console.log("*******************")
    }
})
.catch((err)=>{
    console.log(err)
})
 */

 var myData=""
DoReadFile("../text1.txt")
.then((p1)=>{
    myData+=p1
    return DoReadFile("../text2.txt")
})
.catch((err)=>{
    console.log("error reading text1.txt")
    return DoReadFile("../text2.txt")
})
.then((p1)=>{
    myData+=p1
    return DoReadFile("../text5.txt")
})
.catch((err)=>{
    console.log("error reading text5.txt")
    return Promise.resolve("")
})
.then((p1)=>{
    myData+=p1
    return DoReadFile("../text4.txt")
})
.catch((err)=>{
    console.log("error reading text4.txt")
   })
.then((p1)=>{
    myData+=p1
    
})
.catch((err)=>{
    console.log(err)
})
