var fsPromises=require('fs/promises');

fsPromises.readFile("../text1.txt")
.then((data)=>{
    console.log(data.toString())
})
.catch((err)=>{
    console.log(err)
})
