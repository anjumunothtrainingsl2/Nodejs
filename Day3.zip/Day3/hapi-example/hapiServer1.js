const hapi=require("@hapi/hapi")

const init=async ()=>{
    const server=hapi.server({
        port:3000,
        host:"localhost"
    })
    await server.register([require("@hapi/inert"),
    {
        plugin:require('hapi-mongodb'),
        options:{
            url:"mongodb://localhost:27017/walmartDb",
            settings:{useUnifiedTopology:true},
            decorate:true
        }
    }])
    server.route({
        method:"GET",
        path:"/welcome",
        // request object, response toolkit
        handler:(request,h)=>{
            return "<h1>Welcome to hapi.js project</h1>"

        }
    })
    server.route({
        method:"GET",
        path:"/emp",
        handler:(request,h)=>{
            var obj={"empId":101,"empName":"sara"}
            return obj

        }
    })
    server.route({
        method:"GET",
        path:"/login",
        handler:(request,h)=>{
            return h.file("login.html")
        }

    })
    server.route({
        method:"GET",
        path:"/users",
        handler:(request,h)=>{
            if(request.query.firstName && request.query.lastName)
                return `Welcome ${request.query.firstName}  ${request.query.lastName}`
            else
                return "Welcome Stranger"
        }
    })
    // data is coming in as params
    server.route({
        method:"GET",
        path:"/books/{bookId?}",
        handler:(request,h)=>{
            if(request.params.bookId)
            {
                if(parseInt(request.params.bookId) >0)
                {
                    return `Thanks for ur interest in book: ${request.params.bookId}`
                }
                else
                {
                    return h.response("<h1>BookId does not exists</h1>").code(404)
                }
                
            }
            else
            {
                return " Thanks for ur interest in the book"
            }

        }

    })
    // post ; data is coming as part of body
    server.route({
        path:"/employee",
        method:"POST",
        handler:async (request,h)=>{
            console.log(request.payload)
            result=await request.mongo.db.collection("emp").insertOne(request.payload)
            return "<h1>Thank for entering the details of employee with _id :"+result.insertedId

        }
    })
    // do a redirect
    server.route({
        path:"/",
        method:"GET",
        handler:(req,h)=>{
            return h.redirect("/welcome")

        }
    })

    // send a file as a response
    server.route({
        path:"/flower",
        method:"GET",
        handler:(request,h)=>{
            return h.file("flower.jpg")

        }

    })



    server.route({
        method:"*",
        path:"/{any*}",
        handler:(request,h)=>{
            return h.response("Oh No!!! u seemed to be lost")
        }
    })
    await server.start()
    console.log(`Server is running at ${server.info.uri}`)
}

process.on("unhandledRejection",(err)=>{
    console.log("Error : ",err)
    process.exit(1)
})

init()

// response toolkit ---1. send a response. 2 redirect 3.authentication 4.cookies 5. status code 

// os-utils
// simple-stats-server